#ifndef TDEFENDLINE_HPP
#define TDEFENDLINE_HPP

#include <list>
#include "comdef.h"
#include "tactic.h"
#include "skillSet.h"
#include "beliefState.h"
#include "logger.h"
#include "fieldConfig.h"
namespace Strategy
{
	class TDefendLine : public Tactic
	{
	public:
		TDefendLine(const BeliefState* state, int botID) :
			Tactic(Tactic::Stop, state, botID)
		{ } // TDefendLine

		~TDefendLine()
		{ } // ~TDefendLine

		inline bool isActiveTactic(void) const
		{
			return false;
		}

		int chooseBestBot(std::list<int>& freeBots, const Tactic::Param* tParam) const
		{
			int minv = *(freeBots.begin());
			int mindis = 10000;
			for (std::list<int>::iterator it = freeBots.begin(); it != freeBots.end(); ++it)
			{
				// TODO make the bot choosing process more sophisticated, the logic below returns the 1st available bot
				float dis_from_ball = (state->homePos[*it] - state->ballPos).absSq();
				if(dis_from_ball < mindis)
				{
					dis_from_ball = mindis;
					minv = *it;
				}
			}
			return minv;
		} // chooseBestBot

		void execute(const Param& tParam)
    {
      float x1,x3;
      x1=tParam.DefendLineP.x1;
      x3=state->ballPos.x;
      // Select the skill to the executed next
      if (Vector2D<int>::dist(state->ballPos, state->homePos[botID]) < 2*BOT_BALL_THRESH 
                && (state->ballPos.x > state->homePos[botID].x + BOT_RADIUS))
			{
        Util::Logger::toStdOut("Ball is very near to bot ( %f , %d) --> Spinning ",Vector2D<int>::dist(state->ballPos, state->homePos[botID]),BOT_BALL_THRESH);
        //sID = SkillSet::Spin;
        //sParam.SpinP.radPerSec=MAX_BOT_OMEGA;
        //skillSet->executeSkill(sID, sParam);
//        sID = SkillSet::GoToPointStraight;
        sParam.GoToPointP.x = state->ballPos.x + ForwardX(10);
        sParam.GoToPointP.y = state->ballPos.y + ForwardX(10);
//        sParam.GoToPointP.align = true;
        skillSet->executeSkill(sID, sParam);
			}
      else
      {
        // Intersection of lines from site http://en.wikipedia.org/wiki/Line-line_intersection

        Vector2D<int> targetPoint;
        if(x3 > x1)
        {
          //Skill - Ball has crossed defendline. Shift the defend line before the ball.

//          Util::Logger::toStdOut("Ball has crossed defendline. Shift back defend line. ");
//          float theta = normalizeAngle(Vector2D<int>::angle(Vector2D<int>(HALF_FIELD_MAXX, 0), state->ballPos));
//          float angleWithBall = normalizeAngle(Vector2D<int>::angle(state->ballPos, state->homePos[botID]));
//          targetPoint =   Vector2D<int>(state->ballPos.x+state->ballVel.x*0.3, state->ballPos.y+state->ballVel.y*0.3) 
//                                  - Vector2D<int>(2*BOT_BALL_THRESH*cos(theta), 2*BOT_BALL_THRESH*sin(theta));
          targetPoint.x = state->ballPos.x + 4*BOT_BALL_THRESH;
          targetPoint.y = state->ballPos.y + state->ballVel.x*0.3;

        }
        else
        {
          //Skill - Ball has not crossed defend line. So continue moving along line.
          targetPoint.x = x1;
          targetPoint.y = state->ballPos.y + state->ballVel.x*0.3;
        }
        
        float xfinal = targetPoint.x < HALF_FIELD_MAXX ? targetPoint.x : HALF_FIELD_MAXX;
        float yfinal = targetPoint.y;
        sParam.DefendPointP.x=xfinal;
        sParam.DefendPointP.y=yfinal;
        Util::Logger::toStdOut("Defending Line");  
        sID = SkillSet::DefendPoint;
        skillSet->executeSkill(sID, sParam);
      }
      
      //if (state->pr_ourGoal||state->pr_oppGoal||state->pr_ourFreeKick||state->pr_ourPenalty)
      if(state->pr_ourBall && x3>x1)
      {
        tState = COMPLETED;
      }
      
		}
	}; // class TDefendLine
} // namespace Strategy

#endif // TDEFENDLINE_HPP
