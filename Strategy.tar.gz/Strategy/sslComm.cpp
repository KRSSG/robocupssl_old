#include "sslComm.h"
#include "serial.h"
#include "cs.hpp"
#include "logger.h"

using namespace std;
using namespace Util;

namespace HAL
{
  SSLComm::SSLComm()
  {
    if (!sPort.Open("/dev/ttyUSB0", 9600))
    {
      Logger::abort("Could not open COM port");
    }
  }

  SSLComm::~SSLComm()
  { }

  void SSLComm::sendCommand(int   botID,
                            float v_x,
                            float v_y,
                            float v_t,
                            float kickPower,
                            bool  dribble)
  {
    commCS.enter();
    v_x = -v_x;
    int pwmW1         = (int)((v_t - v_x) * 255.0f / 10);
    int pwmW2         = (int)(((PI / 2 * v_y / 2) + (v_x / 2) + v_t) * 255.0f / 10);
    int pwmW0         = (int)(((-PI / 2 * v_y / 2) + (v_x / 2) + v_t) * 255.0f / 10);

    command.preamble  = 0xAA;
    command.teamColor = (uint8_t)Strategy::HomeTeam::COLOR;
    command.botID     = botID;
    command.dirW0     = pwmW0 < 0 ? 1 : 0;
    command.dirW2     = pwmW2 < 0 ? 1 : 0;
    command.dirW1     = pwmW1 < 0 ? 1 : 0;
    command.dribble   = dribble ? 1 : 0;
    command.kickPower = dribble ?  5 : 0;//(uint8_t) (kickPower*7.999999f);

    if (pwmW1 < 0)
    {
      pwmW1 = -pwmW1;
    }
    if (pwmW2 < 0)
    {
      pwmW2 = -pwmW2;
    }
    if (pwmW0 < 0)
    {
      pwmW0 = -pwmW0;
    }

    command.pwmW0     = pwmW0;
    command.pwmW2     = pwmW2;
    command.pwmW1     = pwmW1;

    sPort.Write(&command, sizeof(SSLPacket));
    commCS.leave();
  }
} // namespace HAL
