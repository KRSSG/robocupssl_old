#ifndef REINFORCEMENT_LEARNING_H
#define REINFORCEMENT_LEARNING_H

namespace Strategy
{
  class RL
  {
  public:
    RL();
    ~RL();
  }; // class RL
} // namespace Strategy

#endif // REINFORCEMENT_LEARNING_H
