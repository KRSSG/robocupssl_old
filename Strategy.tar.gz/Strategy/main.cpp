#include <signal.h>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include "comdef.h"
#include "visionThread.h"
#include "pExec.h"
#include "logger.h"
#include "skillSet.h"
#include "kalman.h"

using namespace std;
using namespace Strategy;

// logger is to be used for logging throughout the project. Use it in other files using extern
Util::CS loggerCS;
Util::Logger logger("timelog.log", Util::Logger::Write, loggerCS);

/* This variable decides if the application should continue running or not.
 * It is true by default and becomes false by pressing Ctrl+C during the runtime.
 */
static bool run = true;

// Define the function to be called when Ctrl+C (SIGINT) signal is sent to process
void signal_callback_handler(int signum)
{
  NOT_USED(signum);
  run = false;
}

void main_constructor(void) __attribute__((constructor));

/* This function performs some sanity checks required for the project
 * to run properly besides other initializations.
 * It is executed before main()
 */
void main_constructor(void)
{
  srand(time(NULL));

  // Ensuring consistency between the two types to team definitions
  if (Strategy::HomeTeam::COLOR == Simulator::BLUE_TEAM)
  {
    assert(Simulator::BlueTeam::ID == Strategy::HOME_TEAM);

    assert(Strategy::AwayTeam::COLOR == Simulator::YELLOW_TEAM);
    assert(Simulator::YellowTeam::ID == Strategy::AWAY_TEAM);

    assert(Strategy::HomeTeam::SIZE == Simulator::BlueTeam::SIZE);
    assert(Strategy::AwayTeam::SIZE == Simulator::YellowTeam::SIZE);
  }
  else if (Strategy::HomeTeam::COLOR == Simulator::YELLOW_TEAM)
  {
    assert(Simulator::YellowTeam::ID == Strategy::HOME_TEAM);

    assert(Strategy::AwayTeam::COLOR == Simulator::BLUE_TEAM);
    assert(Simulator::BlueTeam::ID == Strategy::AWAY_TEAM);

    assert(Strategy::HomeTeam::SIZE == Simulator::YellowTeam::SIZE);
    assert(Strategy::AwayTeam::SIZE == Simulator::BlueTeam::SIZE);
  }
  else
    assert(0); // Invalid COLOR of HomeTeam

  // Register signal and signal handler
  signal(SIGINT, signal_callback_handler);
}


#include "MLP.h"


//checks input stream to see if it's numeric
bool streamIsNumeric(char inp[1024]);

int main(void)
{  
  // will hold the console input
  char inp[1024];

  int noOfBitmaps = 4;
  float learningRate = 0.2;
  float leastMSE = 0.001;
  float momentum = 0.5;

  MLP* neuralnet = new MLP(2, 1, 1, 6);

  if(!(neuralnet->trainNetwork(learningRate, leastMSE, momentum, noOfBitmaps)))
  {
    printf("There was an error while training ... Quitting\n\r");
    printf("\n\rPress any key to continue and exit the program \n\r");
    getchar();
    return -1;
  }

  int number = 5;

  while (number != -1)
  {
    printf("Now that the training is complete, give the number of the case you want to test(0 - %d), or -1 to exit: ", noOfBitmaps - 1);
    cin >> number;

    if(number == -1)
      break;

    // If the recalling goal file does not exit
    if(number < 0 || number > (noOfBitmaps - 1))
      continue; //ask again

    //if we get here, recall the net
    neuralnet->recallNetwork(number);
  }

  printf("\n\rPress any key to continue and exit the program \n\r");
  getchar();

}

//checks input stream to see if it's numeric
bool streamIsNumeric(char inp[1024])
{
  for(int i = 0; i < 1024; i ++)
  {
    //if it the string terminating character
    if(inp[i] == '\0')
      break;//terminate

    //if it is not a digit, return false
    if(!isdigit(inp[i]))
      return false;
  }
  return true;
}

#if 0

int main(void)
{
  Kalman      kFilter;
  BeliefState state;

  VisionThread vThread(kFilter);
  vThread.start();

  SkillSet sk(&state, 0);
  SkillSet::SParam param;
  param.VelocityP.v_x = 0;
  param.VelocityP.v_y = 300;
  param.VelocityP.v_t = 0;

  while (run)
  {
    kFilter.update(state);
    Util::Logger::toStdOut("Acc = %f\n", state.homeAcc[0].abs());
    sk.velocity(param);
    usleep(1000);  // Adding sleep to this thread of execution to prevent CPU hogging
  }
  vThread.stop();
  Util::Logger::toStdOut("Exiting process");
  return 0;
} // main

#endif // 0
