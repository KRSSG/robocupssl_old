#ifndef BELIEF_STATE_H
#define BELIEF_STATE_H

#include "comdef.h"
#include "geometry.hpp"
#include "../sslrefbox/client/game_state.h"

// Forward Declarations
namespace HAL
{
  class VisionInfo;
#ifdef RUN_REFBOX
  class RefBoxCmd;
#endif
}

namespace Strategy
{
  class VisionThread;
#ifdef RUN_REFBOX
  class RefBoxThread;
#endif
}

namespace Strategy
{
  class BeliefState
  {
  private:
    int              prevFrameNum;
    
#ifdef RUN_REFBOX
    unsigned char    refBoxCmdCounter;
    HAL::RefBoxCmd*  refBoxCmdSh;
    Util::CS*        refBoxCS;
    RefBoxThread*    refBoxThread;
#endif

    // stateSh is the shared belief state. It will be shared by the home robots.
  public:
    BeliefState();

    ~BeliefState();

    // It tries to update the belief state. If it does not changes the function returns false else true
    bool      update();

    int       currFrameNum;
    // Game state as reported by the Referee Box
    GameState gameState;

    Point2D<int>    homePos[HomeTeam::SIZE];
    Point2D<int> 	  fieldCentre;
    Point2D<int> 	  home_goalpoints[5];
    Point2D<int>	  opp_goalpoints[5];
    Vector2D<float> homeVel[HomeTeam::SIZE];
    Vector2D<float> homeAcc[HomeTeam::SIZE];
    float           homeAngle[HomeTeam::SIZE];
    float           homeOmega[HomeTeam::SIZE];
    float           homeAngAcc[HomeTeam::SIZE];
    
    Point2D<int>    awayPos[HomeTeam::SIZE];
    Vector2D<float> awayVel[HomeTeam::SIZE];
    Vector2D<float> awayAcc[HomeTeam::SIZE];
    float           awayAngle[HomeTeam::SIZE];
    float           awayOmega[HomeTeam::SIZE];
    float           awayAngAcc[HomeTeam::SIZE];
    
    Point2D<int>    ballPos;
    Vector2D<float> ballVel;
    Vector2D<float> ballAcc;
    // Rarely changing elements from refree box
    int ourGoalCount;
    int oppGoalCount;
    int timeRemaining;
    bool gameHalted;                /* This state is necessary to select the play to halt the robots in their position*/
    bool gameRunning;
    bool ourFreeKick;
    bool oppFreeKick;
    bool ourGoalKick;
    bool oppGoalKick;
    bool ourPenaltyKick;
    bool oppPenaltyKick;

    //------- Set of high-level predicates -------//

    /* This predicates are calculates by computeBallLocation */
    int ourBotNearestToBall;
    int oppBotNearestToBall;
    
    /* The two predicates below are computed in computeBallInDBox() */
    bool ball_in_our_dbox;
    bool ball_in_opp_dbox;
    
    // TODO Unimplemented
    
    // @predicate offense
    bool pr_offense;

    // @predicate defense
    bool pr_defense;

    // @predicate oppBall
    bool pr_oppBall;

    // @predicate ourBall
    bool pr_ourBall;

    // @predicate looseBall
    bool pr_looseBall;

    // @predicate ballOppSide
    bool pr_ballOppSide;

    // @predicate ballOurSide
    bool pr_ballOurSide;

    // @predicate ballMidField
    bool pr_ballMidField;

    // @predicate ballInOurCorner
    bool pr_balInOurCorner;

    // @predicate ballInOppCorner
    bool pr_ballInOppCorner;

    // @predicate ourKickOff
    bool pr_ourKickOff;

    // @predicate oppKickOff
    bool pr_oppKickOff;

    // @predicate ourFreeKick
    bool pr_ourFreeKick;

    // @predicate oppFreeKick
    bool pr_oppFreeKick;

    // @predicate ourPenalty
    bool pr_ourPenalty;

    // @predicate oppPenalty
    bool pr_oppPenalty;

    // Predicates that take an input parameter
    // @predicate nOpponentsOurSide < n >
    bool pr_nOpponentsOurSide(int n);

    // @predicate ballXGt < x >
    bool pr_ballXGt(int x);

    // @predicate ballXLt < x >
    bool pr_ballXLt(int x);

    // @predicate ballAbsYGt < y >
    bool pr_ballAbsYGt(int y);

    // @predicate ballAbsYLt < y >
    bool pr_ballAbsYLt(int y);

    // @predicate ballInSideStrip
    bool pr_ballInSideStrip;
    
    // @predicate ballInFrontStrip
    bool pr_ballInFrontStrip;
    
    // Prototypes for functions that compute the values of the predicates
    void computeBallInDBox();
    void computeOffense();
    void computeDefense();
    
    void computeBallLocation();
    void computeBallOppSide();
    void computeBallOurSide();
    void computeBallMidfield();

    void computeBallInOurCorner();
    void computeBallInOppCorner();

    void computeOurKickOff();
    void computeOppKickOff();

    void computeOurFreeKick();
    void computeOppFreeKick();

    void computeOurPenalty();
    void computeOppPenalty();
    
    void computeBallInStrips();
    // TODO Unimplemented
#if 0
    // @predicate offense
    bool pr_offense;

    // @predicate defense
    bool pr_defense;

    // @predicate oppBall
    bool pr_oppBall;

    // @predicate ourBall
    bool pr_ourBall;

    // @predicate looseBall
    bool pr_looseBall;

    // @predicate ballOppSide
    bool pr_ballOppSide;

    // @predicate ballOurSide
    bool pr_ballOurSide;

    // @predicate ballMidField
    bool pr_ballMidField;

    // @predicate ballInOurCorner
    bool pr_balInOurCorner;

    // @predicate ballInOppCorner
    bool pr_ballInOppCorner;

    // @predicate ourKickOff
    bool pr_ourKickOff;

    // @predicate oppKickOff
    bool pr_oppKickOff;

    // @predicate ourFreeKick
    bool pr_ourFreeKick;

    // @predicate oppFreeKick
    bool pr_oppFreeKick;

    // @predicate ourPenalty
    bool pr_ourPenalty;

    // @predicate oppPenalty
    bool pr_oppPenalty;

    // Predicates that take an input parameter

    // @predicate nOpponentsOurSide < n >
    bool pr_nOpponentsOurSide(int n);

    // @predicate ballXGt < x >
    bool pr_ballXGt(int x);

    // @predicate ballXLt < x >
    bool pr_ballXLt(int x);

    // @predicate ballAbsYGt < y >
    bool pr_ballAbsYGt(int y);

    // @predicate ballAbsYLt < y >
    bool pr_ballAbsYLt(int y);

    // Prototypes for functions that compute the values of the predicates
    void computeOffense();
    void computeDefense();

    void computeOppBall();
    void computeOurBall();
    void computeLooseBall();

    void computeBallOppSide();
    void computeBallOurSide();
    void computeBallMidfield();

    void computeBallInOurCorner();
    void computeBallInOppCorner();

    void computeOurKickOff();
    void computeOppKickOff();

    void computeOurFreeKick();
    void computeOppFreeKick();

    void computeOurPenalty();
    void computeOppPenalty();
#endif // 0
  }; // class BeliefState
} // namespace Strategy

#endif // BELIEF_STATE_H
