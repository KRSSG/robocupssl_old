#include "RL.h"

namespace Strategy
{
  RL::RL()
  {
  }

  RL::~RL()
  {
  }
} // namespace Strategy
