#include <ctime>
#include "beliefState.h"
#include "visionThread.h"
#include "refBoxThread.h"
#include "thread.h"
#include "rbCommDef.h"
#include "cs.hpp"
#include "fieldConfig.h"
#include <logger.h>

using namespace std;
using namespace Util;
using namespace HAL;
using namespace Simulator;

namespace Strategy
{

  BeliefState::BeliefState() :
    prevFrameNum(-1),
#ifdef RUN_REFBOX
    refBoxCmdCounter(-1),
#endif // 
    currFrameNum(-1)
  {
    
#ifdef RUN_REFBOX
    refBoxCmdSh  = new RefBoxCmd();
    refBoxCS     = new CS();
    refBoxThread = new RefBoxThread(refBoxCmdSh, refBoxCS);
    refBoxThread->start();
#endif // RUN_REFBOX

    for (int botID = 0; botID < HomeTeam::SIZE; botID++)
    {
      homeAngle[botID] = 0;
    }

    for (int botID = 0; botID < AwayTeam::SIZE; botID++)
    {
      awayAngle[botID] = 0;
    }
  }

  BeliefState::~BeliefState()
  {
    
#ifdef RUN_REFBOX
    delete refBoxThread;
    delete refBoxCS;
    delete refBoxCmdSh;
#endif // RUN_REFBOX
  }

  bool BeliefState::update()
  {
    bool refreeUpdated = false;
#ifdef RUN_REFBOX
    {
      // Critical Section protected by refBoxCS
      refBoxCS->enter();
      // Updating from Referee Box and the Game State
      if (refBoxCmdCounter != refBoxCmdSh->cmdCounter)
      {
        refreeUpdated = true;
        // HACK Use a function to evaluate ball_kicked during runtime. For the time being its always set to true below
        gameState.transition(refBoxCmdSh->cmd, true);
      }
      refBoxCS->leave();
    } // End of Critical Section protected by refBoxCS
#endif // RUN_REFBOX

    return refreeUpdated;
  } // update
/* Function definitions for all the predicates...
     * */

  void BeliefState::computeBallLocation(){}
  /*{
    int homeNearbotID = -1, awayNearbotID = -1;
    float minDist,distSq,closestBot ;
    minDist = 1000000000.0;
    for( int i = 0; i < HomeTeam::SIZE ; i++)
    {
      float th = Vector2D<int>::angle(ballPos, homePos[i]);
      float theta = NormalizeAngle(th - homeAngle[i]);
        distSq =  Vector2D<int>::distSq(ballPos , homePos[i]);
    
      if(distSq < minDist)
      {
        minDist = distSq;
        closestBot = i;
      }
      this->ourBotNearestToBall = closestBot;
      if(distSq < (BOT_BALL_THRESH * BOT_BALL_THRESH) )//&& fabs(theta) < DRIBBLER_BALL_ANGLE_RANGE)
      {
        homeNearbotID = i;
        break ;
      }
    }
    minDist = 1000000000.0;
    for( int i = 0; i < AwayTeam::SIZE ; i++)
    {
      float theta = firaNormalizeAngle(Vector2D<int>::angle(ballPos, homePos[i]) - awayAngle[i]);	
      distSq = Vector2D<int>::distSq(ballPos , awayPos[i]);
      if(distSq < minDist)
      {
        minDist = distSq;
        closestBot = i;
      }
      this->oppBotNearestToBall = closestBot;
      if(distSq < (BOT_BALL_THRESH * BOT_BALL_THRESH)) //&& fabs(theta) < DRIBBLER_BALL_ANGLE_RANGE)
      {
        awayNearbotID = i;
        break ;
      }
    }
    //printf("OurBotnearest, OppBotNearest : %d %d\n",ourBotNearestToBall,oppBotNearestToBall);
    if( awayNearbotID == -1 && homeNearbotID == -1  )
    {
      pr_looseBall = true;
      pr_oppBall = false;
      pr_ourBall = false;

    }
    else if(awayNearbotID == -1 && homeNearbotID != -1)
    {
      pr_looseBall  =  false;
      pr_oppBall    =  false;
      pr_ourBall    =  true;
    }
    else if(awayNearbotID != -1 && homeNearbotID == -1)
    {
      pr_looseBall  =  false;
      pr_oppBall    =  true;
      pr_ourBall    =  false;
    }
    else if(awayNearbotID != -1 && homeNearbotID != -1)
    {
      pr_looseBall  =  false;
      pr_oppBall    =  true;
      pr_ourBall    =  false;
      
      //TODO: Incorporate bot orientation to decide if homeBot is pointing in the right direction
    }
      
  }*/

  void BeliefState::computeBallInDBox()
  {
      ball_in_opp_dbox = false;
      ball_in_our_dbox = false;
      
      if(ballPos.x < (-HALF_FIELD_MAXX+DBOX_WIDTH)&& 
         ballPos.y <OUR_GOAL_MAXY && 
         ballPos.y >OUR_GOAL_MINY)
           ball_in_our_dbox = true;
      else if(ballPos.x > (HALF_FIELD_MAXX-DBOX_WIDTH)&& 
         ballPos.y <OUR_GOAL_MAXY && 
         ballPos.y >OUR_GOAL_MINY)
           ball_in_opp_dbox = true;
      if(ball_in_our_dbox)
        Util::Logger::toStdOut("\nBALL_IN_OUR_DBOX\n");
      if(ball_in_opp_dbox)
        Util::Logger::toStdOut("\nBALL_IN_OPP_DBOX\n");
  }
  
  //The following three assume that 0,0 is at center of frame (for checking ball parameters)
  
  void BeliefState::computeBallOppSide()
  {
    if((ballPos.x) > 0)
    {
      //MID_FIELD_THRESH is the distance from midfield line into which when ball goes ball's side changes
      if((ballPos.x > fieldCentre.x + MID_FIELD_THRESH) && (pr_ourBall == true)) 
        pr_ballOppSide = true ;
      //check ball VELOCITY
      else if((ballVel.x) * (opp_goalpoints[2].x - fieldCentre.x) > 0) //opp_goalpoints[2] is mid point of goal
        pr_ballOppSide = true ;
      else
        pr_ballOppSide = false;
    }
  }

  void BeliefState::computeBallOurSide()
  {
    if(ballPos.x < fieldCentre.x)
    {
      if((ballPos.x < fieldCentre.x - MID_FIELD_THRESH) && (pr_oppBall == true)) //MID_FIELD_THRESH is the distance from midfield line into which when ball goes ball's side changes
        pr_ballOurSide = true ;
      else if ((ballVel.x) * (opp_goalpoints[2].x - fieldCentre.x) < 0) //opp_goalpoints[2] is mid point of goal
        pr_ballOurSide = true ;
    }
  }

  void BeliefState::computeBallMidfield()
  {

    if((pr_ballOppSide != true) && (pr_ballOurSide != true))
      pr_ballMidField = true ;
  }

  bool BeliefState::pr_nOpponentsOurSide(int n)
  {
    int ctr = 0;
    for( int i = 0; i < AwayTeam::SIZE ; i++)
    {
      if(awayPos[i].x < fieldCentre.x)
        ctr ++ ;
    }
    if(ctr == n)
      return true ;
    else
      return false ;
  }

  bool BeliefState::pr_ballXGt(int x)
  {
    if(ballPos.x > x)
      return true ;
    else
      return false ;
  }

  bool BeliefState::pr_ballXLt(int x)
  {
    if(ballPos.x  < x)
      return true ;
    else
      return false ;
  }

  bool BeliefState::pr_ballAbsYGt(int y)
  {
    int absy = ballPos.y > 0 ? ballPos.y : (-(ballPos.y)) ;
    if(absy > y)
      return true ;
    else
      return false ;
  }

  bool BeliefState::pr_ballAbsYLt(int y)
  {
    int absy = ballPos.y > 0 ? ballPos.y : (-(ballPos.y)) ;
    if(absy < y)
      return true ;
    else
      return false ;
  }
  
  void BeliefState::computeBallInStrips() {
    pr_ballInFrontStrip = (ballPos.x > HALF_FIELD_MAXX - STRIP_WIDTH_X || ballPos.x < -HALF_FIELD_MAXX+STRIP_WIDTH_X);
    pr_ballInSideStrip  = (ballPos.y > HALF_FIELD_MAXY - STRIP_WIDTH_Y || ballPos.y < -HALF_FIELD_MAXY+STRIP_WIDTH_Y);
  }
} // namespace Strategy
