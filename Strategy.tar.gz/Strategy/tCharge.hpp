#ifndef TTCHARGE_HPP
#define TTCHARGE_HPP

#include <list>
#include "comdef.h"
#include "tactic.h"
#include "skillSet.h"
#include "beliefState.h"
#include "logger.h"
#include "fieldConfig.h"

//TODO: Make a tactic such as tStealAndShoot which steals the ball, then shoots it, and 
//      continues the stealing a few times if a goal isn't scored.

namespace Strategy
{
  class TCharge : public Tactic
  {
  public:
    TCharge(const BeliefState* state, int botID) :
      Tactic(Tactic::Stop, state, botID)
    { } // TCharge

    ~TCharge()
    { } // ~TCharge

    inline bool isActiveTactic(void) const
    {
      return true;
    }

    int chooseBestBot(std::list<int>& freeBots, const Tactic::Param* tParam) const
    {
      int minv = *(freeBots.begin());
      int mindis = 10000;
      for (std::list<int>::iterator it = freeBots.begin(); it != freeBots.end(); ++it)
      {
        // TODO make the bot choosing process more sophisticated, the logic below returns the 1st available bot
        float dis_from_ball = (state->homePos[*it] - state->ballPos).absSq();
        if(dis_from_ball < mindis)
        {
          dis_from_ball = mindis;
          minv = *it;
        }
      }
      Util::Logger::toStdOut("Selected bot %d\n", minv);
      return minv;
      
    } // chooseBestBot


    void execute(const Param& tParam)
    {
      // Select the skill to be executed next
      //#undef HALF_FIELD_MAXX
      //#define HALF_FIELD_MAXX -SELECT(3025, 225)
      float theta = normalizeAngle(Vector2D<int>::angle(Vector2D<int>(HALF_FIELD_MAXX, 0), state->ballPos));
      //float angleWithBall = normalizeAngle(Vector2D<int>::angle(state->ballPos, state->homePos[botID]));
      float angleWithFrontPoint = normalizeAngle(Vector2D<int>::angle(state->ballPos+Vector2D<int>(2*BOT_BALL_THRESH*cos(theta), 2*BOT_BALL_THRESH*sin(theta)),state->ballPos));
      Vector2D<int> targetPoint =   Vector2D<int>(state->ballPos.x+state->ballVel.x*0.3, state->ballPos.y+state->ballVel.y*0.3) 
                                  - Vector2D<int>(2*BOT_BALL_THRESH*cos(theta), 2*BOT_BALL_THRESH*sin(theta));
      float dist = Vector2D<int>::dist(targetPoint, state->homePos[botID]);
//      printf("%f, %d, %f, \n", dist, 3*BOT_BALL_THRESH, fabs(firaNormalizeAngle(theta)));
      float sign = (state->homePos[botID].x - state->ballPos.x)*(state->homePos[botID].x - HALF_FIELD_MAXX);
      if(dist < 2*BOT_BALL_THRESH /*&& fabs(firaNormalizeAngle(angleWithFrontPoint - state->homeAngle[botID])) < 0.25*/ && sign > 0)
      {
        Util::Logger::toStdOut("Dribbling to goal");
        //sID = SkillSet::DribbleToPoint;
        //sParam.DribbleToPointP.x = HALF_FIELD_MAXX;
        //sParam.DribbleToPointP.y = 0;
        sID = SkillSet::GoToPoint;
        sParam.GoToPointP.x = state->ballPos.x + 0.5*BOT_BALL_THRESH*cos(theta);
        sParam.GoToPointP.y = state->ballPos.y + 0.5*BOT_BALL_THRESH*sin(theta);
        sParam.GoToPointP.finalslope = normalizeAngle(Vector2D<int>::angle(Vector2D<int>(HALF_FIELD_MAXX,0),
                                                                            state->ballPos ));
//        sParam.GoToPointP.finalVelocity = 0.4;
//        sParam.GoToPointP.align = true;
        skillSet->executeSkill(sID, sParam);
      }
      else{
        Util::Logger::toStdOut("Going to ball");
        sID = SkillSet::GoToPoint;
//        sParam.GoToPointP.align = true;
        sParam.GoToPointP.x = targetPoint.x;
        sParam.GoToPointP.y = targetPoint.y;
        sParam.GoToPointP.finalslope = angleWithFrontPoint;
        skillSet->executeSkill(sID,sParam);
      }
      if (state->pr_oppBall || state->pr_looseBall/*||state->pr_goalscored*/)
        tState = COMPLETED;
      else
        tState = RUNNING;
      
      //#undef HALF_FIELD_MAXX
      //#define HALF_FIELD_MAXX SELECT(3025, 225)
    }
  }; // class TCharge
} // namespace Strategy

#endif // TTCharge_HPP
