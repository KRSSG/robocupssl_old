#include "skillSet.h"
#include "pathPlanners.h"
#include "beliefState.h"
#include "fieldConfig.h"
#include <math.h>
#include <stdio.h>
#define DEFEND_RADIUS 50.0

namespace Strategy
{
  void SkillSet::defendPoint(const SParam& param)
  {
    float point_ball_angle = atan2(state->ballPos.y-param.GoToPointP.y,state->ballPos.x-param.GoToPointP.x);
    Vector2D<int> dpoint;
    printf("Ball : %d, %d\n", state->ballPos.x, state->ballPos.y);
    dpoint.y=param.GoToPointP.y + DEFEND_RADIUS*sin( point_ball_angle);
    dpoint.x=param.GoToPointP.x + DEFEND_RADIUS*cos( point_ball_angle);
//    _goToPoint(botID,dpoint,0,point_ball_angle,0);
  } 
}
