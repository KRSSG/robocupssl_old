#include <sys/time.h>
#include "comdef.h"
#include "kalman.h"
#include "cs.hpp"
#include "beliefState.h"
#include "messages_robocup_ssl_detection.pb.h"
#include "rbCommDef.h"

namespace Strategy
{
  Kalman::Kalman()
  {
    kalmanlog = fopen("kalman.log", "w");
    mutex = new Util::CS();
    for(int id = 0; id < HomeTeam::SIZE; ++id)
    {
      homePose[id].x     = 0;
      homePose[id].y     = 0;
      homeVelocity[id].x = 0;
      homeVelocity[id].y = 0;
      homePosK[id].x     = 1;
      homePosK[id].y     = 1;
      homeAngle[id]      = 0;
      homeOmega[id]      = 0;
      homeAngleK[id]     = 1;
    }
    for(int id = 0; id < AwayTeam::SIZE; id++)
    {
      awayPose[id].x     = 0;
      awayPose[id].y     = 0;
      awayVelocity[id].x = 0;
      awayVelocity[id].y = 0;
      awayPosK[id].x     = 1;
      awayPosK[id].y     = 1;
      awayAngle[id]      = 0;
      awayOmega[id]      = 0;
      awayAngleK[id]     = 1;
    }
    ballPose.x     = 0;
    ballPose.y     = 0;
    ballVelocity.x = 0;
    ballVelocity.y = 0;
    ballPosK.x     = 1;
    ballPosK.y     = 1;
  }

  Kalman::~Kalman()
  {
    fclose(kalmanlog);
  }
  
  void Kalman::addInfo(SSL_DetectionFrame& detection)
  {
    mutex->enter();
    double timeCapture = detection.t_capture();
    int ballsNum                 = detection.balls_size();
    int blueNum                  = detection.robots_blue_size();
    int yellowNum                = detection.robots_yellow_size();

    blueNum                      = MIN(blueNum, Simulator::BlueTeam::SIZE);
    yellowNum                    = MIN(yellowNum, Simulator::YellowTeam::SIZE);

    SSL_DetectionBall ball;
    if (ballsNum > 0)
    {
      ball = detection.balls(0);
    }
    
    if (HomeTeam::COLOR == Simulator::BLUE_TEAM)
    {
      // Blue robot info
      for (int i = 0; i < blueNum; ++i)
      {
        SSL_DetectionRobot robot = detection.robots_blue(i);
        int                id    = HAL::BlueMarkerMap[robot.robot_id()];
        double           delTime = timeCapture - homeLastUpdateTime[id];

        homePosSigmaSqK[id].x    = homePosSigmaSqK[id].x * ( 1 - homePosK[id].x) + SIGMA_SQ_NOISE * delTime;
        homePosK[id].x           = homePosSigmaSqK[id].x / (homePosSigmaSqK[id].x + SIGMA_SQ_OBSVN);
        float  predictedPoseX    = homePose[id].x + homeVelocity[id].x * (delTime);
        float  lastPoseX         = homePose[id].x;
        homePose[id].x           = predictedPoseX + homePosK[id].x * (robot.x() - predictedPoseX);
				float lastVelocityx      = homeVelocity[id].x;
        homeVelocity[id].x       = (homePose[id].x - lastPoseX) / delTime;
				homeAcc[id].x            = (homeVelocity[id].x - lastVelocityx) / delTime;
				
        homePosSigmaSqK[id].y    = homePosSigmaSqK[id].y * ( 1 - homePosK[id].y) + SIGMA_SQ_NOISE * delTime;
        homePosK[id].y           = homePosSigmaSqK[id].y / (homePosSigmaSqK[id].y + SIGMA_SQ_OBSVN);
        float  predictedPoseY    = homePose[id].y + homeVelocity[id].y * (delTime);
        float  lastPoseY         = homePose[id].y;
        homePose[id].y           = predictedPoseY + homePosK[id].y * (robot.y() - predictedPoseY);
				float lastVelocityy      = homeVelocity[id].y;
        homeVelocity[id].y       = (homePose[id].y - lastPoseY) / delTime;
				homeAcc[id].y            = (homeVelocity[id].y - lastVelocityy) / delTime;
				
        homeAngleSigmaSqK[id]    = homeAngleSigmaSqK[id] * ( 1 - homeAngleK[id]) + SIGMA_SQ_NOISE * delTime;
        homeAngleK[id]           = homeAngleSigmaSqK[id] / (homeAngleSigmaSqK[id] + SIGMA_SQ_OBSVN);
        float  predictedAngle    = homeAngle[id] + homeOmega[id] * (delTime);
        float  lastAngle         = homeAngle[id];
        homeAngle[id]            = predictedAngle + homeAngleK[id] * (robot.orientation() - predictedAngle);
				float lastAngularV       = homeOmega[id];
        homeOmega[id]            = (homeAngle[id] - lastAngle) / delTime;
				homeAngularAcc[id]       = (homeOmega[id] - lastAngularV) / delTime;

        homeLastUpdateTime[id]   = timeCapture;
      }

      // Yellow robot info
      for (int i = 0; i < yellowNum; ++i)
      {
        SSL_DetectionRobot robot = detection.robots_yellow(i);
        int                id    = HAL::YellowMarkerMap[robot.robot_id()];
        double           delTime = timeCapture - awayLastUpdateTime[id];

        awayPosSigmaSqK[id].x    = awayPosSigmaSqK[id].x * ( 1 - awayPosK[id].x) + SIGMA_SQ_NOISE * delTime;
        awayPosK[id].x           = awayPosSigmaSqK[id].x / (awayPosSigmaSqK[id].x + SIGMA_SQ_OBSVN);
        float  predictedPoseX    = awayPose[id].x + awayVelocity[id].x * (delTime);
        float  lastPoseX         = awayPose[id].x;
        awayPose[id].x           = predictedPoseX + awayPosK[id].x * (robot.x() - predictedPoseX);
        float lastVelocityx      = awayVelocity[id].x;
        awayVelocity[id].x       = (awayPose[id].x - lastPoseX) / delTime;
				awayAcc[id].x            = (awayVelocity[id].x - lastVelocityx) / delTime;
				
        awayPosSigmaSqK[id].y    = awayPosSigmaSqK[id].y * ( 1 - awayPosK[id].y) + SIGMA_SQ_NOISE * delTime;
        awayPosK[id].y           = awayPosSigmaSqK[id].y / (awayPosSigmaSqK[id].y + SIGMA_SQ_OBSVN);
        float  predictedPoseY    = awayPose[id].y + awayVelocity[id].y * (delTime);
        float  lastPoseY         = awayPose[id].y;
        awayPose[id].y           = predictedPoseY + awayPosK[id].y * (robot.y() - predictedPoseY);
        float lastVelocityy      = awayVelocity[id].y;
        awayVelocity[id].y       = (awayPose[id].y - lastPoseY) / delTime;
				awayAcc[id].y            = (awayVelocity[id].y - lastVelocityy) / delTime;
				
        awayAngleSigmaSqK[id]    = awayAngleSigmaSqK[id] * ( 1 - awayAngleK[id]) + SIGMA_SQ_NOISE * delTime;
        awayAngleK[id]           = awayAngleSigmaSqK[id] / (awayAngleSigmaSqK[id] + SIGMA_SQ_OBSVN);
        float  predictedAngle    = awayAngle[id] + awayOmega[id] * (delTime);
        float  lastAngle         = awayAngle[id];
        awayAngle[id]            = predictedAngle + awayAngleK[id] * (robot.orientation() - predictedAngle);
        float lastAngularV       = awayOmega[id];
        awayOmega[id]            = (awayAngle[id] - lastAngle) / delTime;
				awayAngularAcc[id]       = (awayOmega[id] - lastAngularV) / delTime;

        awayLastUpdateTime[id]   = timeCapture;
      }
    }
    else
    {
      // Blue robot info
      for (int i = 0; i < blueNum; ++i)
      {
        SSL_DetectionRobot robot = detection.robots_blue(i);
        int                id    = HAL::BlueMarkerMap[robot.robot_id()];
        double           delTime = timeCapture - awayLastUpdateTime[id];

        homePosSigmaSqK[id].x    = homePosSigmaSqK[id].x * ( 1 - homePosK[id].x) + SIGMA_SQ_NOISE * delTime;
        homePosK[id].x           = homePosSigmaSqK[id].x / (homePosSigmaSqK[id].x + SIGMA_SQ_OBSVN);
        float  predictedPoseX    = homePose[id].x + homeVelocity[id].x * (delTime);
        float  lastPoseX         = homePose[id].x;
        homePose[id].x           = predictedPoseX + homePosK[id].x * (robot.x() - predictedPoseX);
				float lastVelocityx      = homeVelocity[id].x;
        homeVelocity[id].x       = (homePose[id].x - lastPoseX) / delTime;
				homeAcc[id].x            = (homeVelocity[id].x - lastVelocityx) / delTime;
				
        homePosSigmaSqK[id].y    = homePosSigmaSqK[id].y * ( 1 - homePosK[id].y) + SIGMA_SQ_NOISE * delTime;
        homePosK[id].y           = homePosSigmaSqK[id].y / (homePosSigmaSqK[id].y + SIGMA_SQ_OBSVN);
        float  predictedPoseY    = homePose[id].y + homeVelocity[id].y * (delTime);
        float  lastPoseY         = homePose[id].y;
        homePose[id].y           = predictedPoseY + homePosK[id].y * (robot.y() - predictedPoseY);
				float lastVelocityy      = homeVelocity[id].y;
        homeVelocity[id].y       = (homePose[id].y - lastPoseY) / delTime;
				homeAcc[id].y            = (homeVelocity[id].y - lastVelocityy) / delTime;
				
        homeAngleSigmaSqK[id]    = homeAngleSigmaSqK[id] * ( 1 - homeAngleK[id]) + SIGMA_SQ_NOISE * delTime;
        homeAngleK[id]           = homeAngleSigmaSqK[id] / (homeAngleSigmaSqK[id] + SIGMA_SQ_OBSVN);
        float  predictedAngle    = homeAngle[id] + homeOmega[id] * (delTime);
        float  lastAngle         = homeAngle[id];
        homeAngle[id]            = predictedAngle + homeAngleK[id] * (robot.orientation() - predictedAngle);
				float lastAngularV       = homeOmega[id];
        homeOmega[id]            = (homeAngle[id] - lastAngle) / delTime;
				homeAngularAcc[id]       = (homeOmega[id] - lastAngularV) / delTime;

        homeLastUpdateTime[id]   = timeCapture;
      }

      // Yellow robot info
      for (int i = 0; i < yellowNum; ++i)
      {
        SSL_DetectionRobot robot = detection.robots_yellow(i);
        int                id    = HAL::YellowMarkerMap[robot.robot_id()];
        double           delTime = timeCapture - homeLastUpdateTime[id];

        awayPosSigmaSqK[id].x    = awayPosSigmaSqK[id].x * ( 1 - awayPosK[id].x) + SIGMA_SQ_NOISE * delTime;
        awayPosK[id].x           = awayPosSigmaSqK[id].x / (awayPosSigmaSqK[id].x + SIGMA_SQ_OBSVN);
        float  predictedPoseX    = awayPose[id].x + awayVelocity[id].x * (delTime);
        float  lastPoseX         = awayPose[id].x;
        awayPose[id].x           = predictedPoseX + awayPosK[id].x * (robot.x() - predictedPoseX);
        float lastVelocityx      = awayVelocity[id].x;
        awayVelocity[id].x       = (awayPose[id].x - lastPoseX) / delTime;
				awayAcc[id].x            = (awayVelocity[id].x - lastVelocityx) / delTime;
				
        awayPosSigmaSqK[id].y    = awayPosSigmaSqK[id].y * ( 1 - awayPosK[id].y) + SIGMA_SQ_NOISE * delTime;
        awayPosK[id].y           = awayPosSigmaSqK[id].y / (awayPosSigmaSqK[id].y + SIGMA_SQ_OBSVN);
        float  predictedPoseY    = awayPose[id].y + awayVelocity[id].y * (delTime);
        float  lastPoseY         = awayPose[id].y;
        awayPose[id].y           = predictedPoseY + awayPosK[id].y * (robot.y() - predictedPoseY);
        float lastVelocityy      = awayVelocity[id].y;
        awayVelocity[id].y       = (awayPose[id].y - lastPoseY) / delTime;
				awayAcc[id].y            = (awayVelocity[id].y - lastVelocityy) / delTime;
				
        awayAngleSigmaSqK[id]    = awayAngleSigmaSqK[id] * ( 1 - awayAngleK[id]) + SIGMA_SQ_NOISE * delTime;
        awayAngleK[id]           = awayAngleSigmaSqK[id] / (awayAngleSigmaSqK[id] + SIGMA_SQ_OBSVN);
        float  predictedAngle    = awayAngle[id] + awayOmega[id] * (delTime);
        float  lastAngle         = awayAngle[id];
        awayAngle[id]            = predictedAngle + awayAngleK[id] * (robot.orientation() - predictedAngle);
        float lastAngularV       = awayOmega[id];
        awayOmega[id]            = (awayAngle[id] - lastAngle) / delTime;
				awayAngularAcc[id]       = (awayOmega[id] - lastAngularV) / delTime;

        awayLastUpdateTime[id]   = timeCapture;
      }
    }

    // Ball info
    if (ballsNum > 0)
    {
      double           delTime = timeCapture - ballLastUpdateTime;

      ballPosSigmaSqK.x          = ballPosSigmaSqK.x * ( 1 - ballPosK.x) + SIGMA_SQ_NOISE * delTime;
      ballPosK.x                 = ballPosSigmaSqK.x / (ballPosSigmaSqK.x + SIGMA_SQ_OBSVN);
      float  predictedPoseX      = ballPose.x + ballVelocity.x * (delTime);
      float  lastPoseX           = ballPose.x;
      ballPose.x                 = predictedPoseX + ballPosK.x * (ball.x() - predictedPoseX);
			float lastVelocityx        = ballVelocity.x;
      ballVelocity.x             = (ballPose.x - lastPoseX) / delTime;
			ballAcceleration.x         = (ballVelocity.x - lastVelocityx) / delTime;

      ballPosSigmaSqK.y          = ballPosSigmaSqK.y * ( 1 - ballPosK.y) + SIGMA_SQ_NOISE * delTime;
      ballPosK.y                 = ballPosSigmaSqK.y / (ballPosSigmaSqK.y + SIGMA_SQ_OBSVN);
      float  predictedPoseY      = ballPose.y + ballVelocity.y * (delTime);
      float  lastPoseY           = ballPose.y;
      ballPose.y                 = predictedPoseY + ballPosK.y * (ball.y() - predictedPoseY);
			float lastVelocityy        = ballVelocity.y;
      ballVelocity.y             = (ballPose.y - lastPoseY) / delTime;
			ballAcceleration.y         = (ballVelocity.y - lastVelocityy) / delTime;

      ballLastUpdateTime         = timeCapture;
    }
    mutex->leave();
  }

  void Kalman::update(BeliefState& state)
  {
    mutex->enter();
    for (int botID = 0; botID < HomeTeam::SIZE; ++botID)
    {
      state.homePos[botID]   = Vector2D<int>(homePose[botID].x, homePose[botID].y);
      state.homeAngle[botID] = homeAngle[botID];
      state.homeVel[botID]   = homeVelocity[botID];
      state.homeOmega[botID] = homeOmega[botID];
			state.homeAcc[botID]   = homeAcc[botID];
			state.homeAngAcc[botID]= homeAngularAcc[botID];
    }
    for (int botID = 0; botID < AwayTeam::SIZE; ++botID)
    {
      state.awayPos[botID]   = Vector2D<int>(awayPose[botID].x, awayPose[botID].y);
      state.awayAngle[botID] = awayAngle[botID];
      state.awayVel[botID]   = awayVelocity[botID];
      state.awayOmega[botID] = awayOmega[botID];
			state.awayAcc[botID]   = awayAcc[botID];
			state.awayAngAcc[botID]= awayAngularAcc[botID];
    }
    state.ballPos = Vector2D<int>(ballPose.x, ballPose.y);
		state.ballVel = ballVelocity;
		state.ballAcc = ballAcceleration;
    mutex->leave();
  }
}
